export interface  Movielist {
    year: string,
    title: string,
    studios: string,
    producers: string,
    winner?: string
}