# Teste :  Pedro joaquim da costa

RestfullAPI  node js de movies .

## Installation

Para instalar o projecto 

```bash
npm i  ou  npm install
```
Para compilar o projecto 

```bash
npm run compile
```


Para executar o teste de integration

```bash
npm run integrationTest
```

Para executar  projecto por completo

```bash
npm run execute
```


Todas as rotas 

```bash

  Get :   api/v1/movies

  Get :   api/v1/movies/winners

  Get :   api/v1/movies/:id

  Post:   api/v1/movies

  Put :   api/v1/movies/:id

  Delete: api/v1/movies/:id


```
